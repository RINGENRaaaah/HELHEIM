fun main(args: Array<String>) {
    println("Hello World!")

    // Try adding program arguments via Run/Debug configuration.
    // Learn more about running applications: https://www.jetbrains.com/help/idea/running-applications.html.
    println("Program arguments: ${args.joinToString()}")


    var    st1 = 6
    var    st2 = 12
    var    st3 = 18
    var    st4 = 24
    var    st5 = 30
    var    st6 = 36
    var    st7 = 42
    var    st8 = 48
    var    st9 = 54
    var    st10 = 60
    println("1 - Dec"+" - "+(st1)+" | "+"Bin"+" - "+Integer.toString(st1,2)+" | "+"Hex"+" - "+Integer.toString(st1,16))
    println("2 - Dec"+" - "+(st2)+" | "+"Bin"+" - "+Integer.toString(st2,2)+" | "+"Hex"+" - "+Integer.toString(st2,16))
    println("3 - Dec"+" - "+(st3)+" | "+"Bin"+" - "+Integer.toString(st3,2)+" | "+"Hex"+" - "+Integer.toString(st3,16))
    println("4 - Dec"+" - "+(st4)+" | "+"Bin"+" - "+Integer.toString(st4,2)+" | "+"Hex"+" - "+Integer.toString(st4,16))
    println("5 - Dec"+" - "+(st5)+" | "+"Bin"+" - "+Integer.toString(st5,2)+" | "+"Hex"+" - "+Integer.toString(st5,16))
    println("6 - Dec"+" - "+(st6)+" | "+"Bin"+" - "+Integer.toString(st6,2)+" | "+"Hex"+" - "+Integer.toString(st6,16))
    println("7 - Dec"+" - "+(st7)+" | "+"Bin"+" - "+Integer.toString(st7,2)+" | "+"Hex"+" - "+Integer.toString(st4,16))
    println("8 - Dec"+" - "+(st8)+" | "+"Bin"+" - "+Integer.toString(st8,2)+" | "+"Hex"+" - "+Integer.toString(st8,16))
    println("9 - Dec"+" - "+(st9)+" | "+"Bin"+" - "+Integer.toString(st9,2)+" | "+"Hex"+" - "+Integer.toString(st9,16))
    println("10 - Dec"+" - "+(st10)+" | "+"Bin"+" - "+Integer.toString(st10,2)+" | "+"Hex"+" - "+Integer.toString(st10,16))











}